
package My::Province;

use strict;
use warnings 'all';
use base 'My::State';

#__PACKAGE__->set_up_table( __PACKAGE__->SUPER::table );

1;# return true:

